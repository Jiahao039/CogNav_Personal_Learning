# Order of imports is important (see warning otherwise when running tests)
import setuptools  # isort:skip # noqa
import distutils  # isort:skip # noqa
