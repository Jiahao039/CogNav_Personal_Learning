from omegaconf.resolvers import oc

__all__ = [
    "oc",
]
